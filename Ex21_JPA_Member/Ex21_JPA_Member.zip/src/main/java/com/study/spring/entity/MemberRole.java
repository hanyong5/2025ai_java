package com.study.spring.entity;

public enum MemberRole {
	 USER, MANAGER,ADMIN;
}
